/**
 * @file controller.hpp
 * @author Tim Weynands
 * @brief Definitionsdatei der Klasse Controller zur Steuerung einer Ampelschaltung.
 * @date 06.03.2025
 */

#ifndef _CONTROLLER_
#define _CONTROLLER_

#include <Arduino.h>
#include "light.hpp"
#include "button.hpp"
#include <TimerOne.h>

// --- Pin-Definitionen ---
#define BUTTON_PIN     2  ///< Pin für den Taster
#define VEH_LED_RT_PIN 13 ///< Pin für Fahrzeug-Rotlicht
#define VEH_LED_GE_PIN 12 ///< Pin für Fahrzeug-Gelb
#define VEH_LED_GN_PIN 11 ///< Pin für Fahrzeug-Grün
#define PED_LED_RT_PIN 10 ///< Pin für Fußgänger-Rotlicht
#define PED_LED_GN_PIN 9  ///< Pin für Fußgänger-Grün
#define BUZZER_PIN     8  ///< Pin für den Buzzer

// --- Zeitkonstanten für die Ampelschaltung ---
#define VEH_GN_DAUER    50  ///< Dauer für Fahrzeug-Grün (6 Sekunden)
#define VEH_GNWAIT_DEL  5   ///< Wartezeit nach Grünphase (0.6 Sekunden)
#define VEH_GE_DAUER    15  ///< Dauer für Fahrzeug-Gelb (3 Sekunden)
#define VEH_RT_DAUER    50  ///< Dauer für Fahrzeug-Rot (6 Sekunden)
#define VEH_RTGE_DAUER  5   ///< Dauer für Fahrzeug-Rot/Gelb (1 Sekunde)
#define DELAY           5   ///< Verzögerung (1 Sekunde)

extern volatile int timerCount; ///< Zählt Timer-Interrupts zur Steuerung der Ampel.
void timerISR(); ///< ISR für den Timer-Interrupt.

extern volatile byte receivedData; ///< Empfangene Daten vom I²C-Bus.

/**
 * @class Controller
 * @brief Klasse zur Steuerung einer ereignisgesteuerten Ampelanlage.
 */
class Controller {
  public:
    /**
     * @brief Konstruktor für den Controller.
     * @param veh_rtPin Pin für Fahrzeug-Rotlicht
     * @param veh_gePin Pin für Fahrzeug-Gelb
     * @param veh_gnPin Pin für Fahrzeug-Grün
     * @param ped_rtPin Pin für Fußgänger-Rotlicht
     * @param ped_gnPin Pin für Fußgänger-Grün
     * @param buttonPin Pin für den Fußgängertaster
     * @param buzzerPin Pin für den akustischen Signalgeber
     */
    Controller(int veh_rtPin = VEH_LED_RT_PIN,
               int veh_gePin = VEH_LED_GE_PIN,
               int veh_gnPin = VEH_LED_GN_PIN,
               int ped_rtPin = PED_LED_RT_PIN,
               int ped_gnPin = PED_LED_GN_PIN,
               int buttonPin = BUTTON_PIN,
               int buzzerPin = BUZZER_PIN);

    /**
     * @brief Startet die Ampelsteuerung basierend auf dem aktuellen Zustand.
     */
    void start();

  private:
    /**
     * @brief Setzt alle Ampel-LEDs entsprechend den angegebenen Zuständen.
     * @param veh_rt Fahrzeug-Rotlicht (HIGH/LOW)
     * @param veh_ge Fahrzeug-Gelb (HIGH/LOW)
     * @param veh_gn Fahrzeug-Grün (HIGH/LOW)
     * @param ped_rt Fußgänger-Rotlicht (HIGH/LOW)
     * @param ped_gn Fußgänger-Grün (HIGH/LOW)
     */
    void switchAll(byte veh_rt, byte veh_ge, byte veh_gn, byte ped_rt, byte ped_gn);

    /**
     * @enum LZAState
     * @brief Zustände der Ampelschaltung.
     */
    enum LZAState {
        VEH_RT,    ///< Fahrzeug-Rot
        VEH_GE,    ///< Fahrzeug-Gelb
        VEH_GN,    ///< Fahrzeug-Grün
        VEH_RTGE,  ///< Fahrzeug Rot-Gelb (Übergang zu Grün)
        VEH_GNWAIT,///< Wartephase nach Grün (zur Erkennung eines Fußgängers)
        NUM_STATES ///< Anzahl der Zustände
    };

    LZAState state; ///< Aktueller Zustand der Ampelschaltung.

    Light veh_led_rt; ///< Fahrzeug-Rotlicht
    Light veh_led_ge; ///< Fahrzeug-Gelblicht
    Light veh_led_gn; ///< Fahrzeug-Grünlicht
    Light ped_led_rt; ///< Fußgänger-Rotlicht
    Light ped_led_gn; ///< Fußgänger-Grünlicht
    Light buzzer;     ///< Akustisches Signal
    Button button;    ///< Fußgängertaster
};

#endif
