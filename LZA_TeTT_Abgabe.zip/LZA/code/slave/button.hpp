/**
 * @file button.hpp
 * @brief Definitionsdatei der Klasse Button.
 * @author Tim Weynands, Tobias Radtke
 * @date 06.03.2025
 */

#ifndef _MY_BUTTON_
#define _MY_BUTTON_

#include "Arduino.h"
#include "light.hpp"

/**
 * @class Button
 * @brief Klasse zur Verwaltung eines Tasters mit Entprellung.
 */
class Button {
public:
    /**
     * @brief Konstruktor der Klasse Button.
     * @param pin Der Pin, an dem der Button angeschlossen ist. Standard: 2.
     */
    Button(byte pin = 2);

    /**
     * @brief Interrupt Service Routine (ISR) für den Taster.
     * Wird aufgerufen, wenn der Taster gedrückt wird.
     */
    static void pushISR();

    /**
     * @brief Setzt den internen Tasterstatus zurück.
     */
    void reset();

    /**
     * @brief Prüft, ob der Button gedrückt wurde.
     * @return `true`, wenn der Button gedrückt wurde, sonst `false`.
     */
    bool isPushed();

    /**
     * @brief Initialisiert den Button.
     * @param pin Der GPIO-Pin, an dem der Button angeschlossen ist.
     */
    void init(int pin);

    /** 
     * @brief Speichert den Tasterstatus (`true` = gedrückt, `false` = nicht gedrückt). 
     */
    static bool pushed;

private:
    int pin; /**< Der GPIO-Pin, an dem der Button angeschlossen ist. */
};

#endif // _MY_BUTTON_
