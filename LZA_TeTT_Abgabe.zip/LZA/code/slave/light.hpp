/**
 * @file light.hpp
 * @author Tim Weynands, Tobias Radtke
 * @brief Definitionsdatei der Klasse Light zur Steuerung einer LED.
 * @date 06.03.2025
 */

#ifndef _LIGHT_
#define _LIGHT_

#define LED_BUILTIN 13  ///< Standard-LED-Pin für Arduino

#include "Arduino.h"

/**
 * @class Light
 * @brief Klasse zur Steuerung einer LED.
 */
class Light {
  public:
    /**
     * @brief Konstruktor der Klasse Light.
     * @param pin Der Pin, an dem die LED angeschlossen ist (Standard: LED_BUILTIN).
     */
    Light (byte pin = LED_BUILTIN);

    /**
     * @brief Initialisiert die LED mit dem angegebenen Pin.
     * @param pin Der Pin, an dem die LED angeschlossen ist (Standard: LED_BUILTIN).
     */
    void init (int pin = LED_BUILTIN);

    /**
     * @brief Schaltet die LED ein.
     */
    void switchOn ();

    /**
     * @brief Schaltet die LED aus.
     */
    void switchOff ();

    /**
     * @brief Wechselt den Zustand der LED (ein/aus).
     */
    void toogle ();

    /**
     * @brief Gibt den aktuellen Zustand der LED zurück.
     * @return true, wenn die LED eingeschaltet ist, sonst false.
     */
    bool isOn ();

  private:
    int pin;  ///< Speichert den Pin, an dem die LED angeschlossen ist.
};

#endif
