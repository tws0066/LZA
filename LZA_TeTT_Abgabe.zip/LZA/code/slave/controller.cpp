/**
 * @file controller.cpp
 * @author Tim Weynands
 * @brief Implementierung der Steuerlogik für die Ampelanlage.
 * @date 06.03.2025
 */

#include <Wire.h>
#include "controller.hpp"

/**
 * @brief Zähler für den Timer, der die Zeit in der Steuerung misst.
 * 
 * Der Zähler wird in der Timer Interrupt Service Routine (ISR) um 1 erhöht.
 */
volatile int timerCount = 0;

/**
 * @brief Interrupt-Service-Routine für den Timer.
 * 
 * Diese ISR wird aufgerufen, wenn der Timer ausgelöst wird, und erhöht den 
 * globalen Zähler `timerCount`.
 */
void timerISR() {
  timerCount++;
}

/**
 * @brief Konstruktor der Controller-Klasse.
 * 
 * Initialisiert alle benötigten Pins und setzt die Anfangswerte für die 
 * Ampelanlage und den Taster.
 * 
 * @param veh_rtPin Pin für die rote Verkehrslampe des Fahrzeugs.
 * @param veh_gePin Pin für die grüne Verkehrslampe des Fahrzeugs.
 * @param veh_gnPin Pin für die gelbe Verkehrslampe des Fahrzeugs.
 * @param ped_rtPin Pin für die rote Fußgängerlampe.
 * @param ped_gnPin Pin für die grüne Fußgängerlampe.
 * @param buttonPin Pin für den Taster (z. B. für Fußgängeranforderung).
 * @param buzzerPin Pin für den Summer.
 */
Controller::Controller(
  int veh_rtPin,
  int veh_gePin,
  int veh_gnPin,
  int ped_rtPin,
  int ped_gnPin,
  int buttonPin,
  int buzzerPin) {

  veh_led_rt.init(veh_rtPin); ///< Initialisiert die rote Verkehrslampe des Fahrzeugs.
  veh_led_ge.init(veh_gePin); ///< Initialisiert die grüne Verkehrslampe des Fahrzeugs.
  veh_led_gn.init(veh_gnPin); ///< Initialisiert die gelbe Verkehrslampe des Fahrzeugs.
  ped_led_rt.init(ped_rtPin); ///< Initialisiert die rote Fußgängerlampe.
  ped_led_gn.init(ped_gnPin); ///< Initialisiert die grüne Fußgängerlampe.
  button.init(buttonPin);     ///< Initialisiert den Taster.
  state = VEH_GNWAIT;        ///< Setzt den anfänglichen Zustand der Ampelanlage.
  switchAll(LOW, LOW, HIGH, HIGH, LOW); ///< Initialer Zustand der Lampen.
  buzzer.init(buzzerPin);     ///< Initialisiert den Summer.
}

/**
 * @brief Startet die Ampelsteuerung und wechselt die Zustände basierend auf dem Timer.
 * 
 * Dieser Funktion implementiert die Steuerlogik der Ampelanlage, einschließlich der 
 * verschiedenen Phasen für Fahrzeug- und Fußgängerampeln. Sie überprüft, wie lange
 * der Timer läuft, und wechselt den Zustand nach einer festgelegten Dauer.
 */
void Controller::start() {
  switch (this->state) {
    case VEH_GN:
      switchAll(LOW, LOW, HIGH, HIGH, LOW); ///< Fahrzeuggrün leuchtet, Fußgängerrot leuchtet.
      if (timerCount >= VEH_GN_DAUER){
        this->state = VEH_GNWAIT;   ///< Wechsel zum Fahrzeug-Warten-Zustand.
        timerCount = 0;
      }
      break;

    case VEH_GNWAIT:
      if (receivedData == 1) {  ///< Wenn der Taster gedrückt wurde, wechselt der Zustand.
        if(timerCount >= VEH_GNWAIT_DEL){
          this->state = VEH_GE;  ///< Fahrzeug-Gelb.
          timerCount = 0;
          receivedData = 0;     ///< Reset der empfangenen Daten.
          button.reset();       ///< Reset des Tasters.
        }
      }
      break;

    case VEH_GE:
      switchAll(LOW, HIGH, LOW, HIGH, LOW); ///< Fahrzeuggelb und Fußgängerrot.
      if(timerCount >= VEH_GE_DAUER){
        this->state = VEH_RT;  ///< Wechsel zu Fahrzeug-Rot.
        timerCount = 0;
      }
      break;

    case VEH_RT:
      if(timerCount >= DELAY) {
        switchAll(HIGH, LOW, LOW, LOW, HIGH); ///< Fahrzeugrot und Fußgängergrün.
        tone(BUZZER_PIN, 1000); 
        if(timerCount >= VEH_RT_DAUER){
          this->state = VEH_RTGE;  ///< Wechsel zu Fahrzeug-Rot-Gelb.
          noTone(BUZZER_PIN);      ///< Stoppe den Ton.
          timerCount = 0;
        }
      }
      break;

    case VEH_RTGE:
      // Fahrzeugrot-Gelb und Fußgängergrün.
      switchAll(HIGH, HIGH, LOW, HIGH, LOW);
      if(timerCount >= VEH_RTGE_DAUER){
        this->state = VEH_GN;  ///< Wechsel zurück zu Fahrzeug-Grün.
        timerCount = 0;
      }
      break;
    
    default:
      Serial.print("ERROR INVALID STATE"); ///< Fehlerbehandlung bei ungültigem Zustand.
      break;
  }
}

/**
 * @brief Schaltet alle Lichter der Ampelanlage basierend auf den angegebenen Parametern.
 * 
 * @param veh_rt Zustand der roten Fahrzeugampel.
 * @param veh_ge Zustand der grünen Fahrzeugampel.
 * @param veh_gn Zustand der gelben Fahrzeugampel.
 * @param ped_rt Zustand der roten Fußgängerampel.
 * @param ped_gn Zustand der grünen Fußgängerampel.
 */
void Controller::switchAll(
  byte veh_rt,
  byte veh_ge,
  byte veh_gn,
  byte ped_rt,
  byte ped_gn) {
  veh_rt ? veh_led_rt.switchOn() : veh_led_rt.switchOff(); ///< Steuerung der roten Fahrzeugampel.
  veh_ge ? veh_led_ge.switchOn() : veh_led_ge.switchOff(); ///< Steuerung der grünen Fahrzeugampel.
  veh_gn ? veh_led_gn.switchOn() : veh_led_gn.switchOff(); ///< Steuerung der gelben Fahrzeugampel. 
  ped_rt ? ped_led_rt.switchOn() : ped_led_rt.switchOff(); ///< Steuerung der roten Fußgängerampel.
  ped_gn ? ped_led_gn.switchOn() : ped_led_gn.switchOff(); ///< Steuerung der grünen Fußgängerampel.  
}