/**
 * @file hamming.hpp
 * @author Tim Weynands, Tobias Radtke
 * @brief Definitionsdatei der Klasse Hamming zur Fehlerkorrektur mittels Hamming-Code.
 * @date 06.03.2025
 */

#ifndef HAMMING_HPP
#define HAMMING_HPP

#include <Arduino.h>

typedef unsigned char byte;  ///< Alias für ein Byte (8 Bit).

/**
 * @class Hamming
 * @brief Implementierung des Hamming(7,4)-Codes zur Fehlerkorrektur.
 */
class Hamming {
public:
    /**
     * @brief Kodiert ein 4-Bit-Datenbyte in ein 7-Bit-Hamming-Codewort.
     * @param data Die zu kodierenden 4 Datenbits.
     * @return Das kodierte 7-Bit-Hamming-Wort als Byte.
     */
    static byte code(byte data);

    /**
     * @brief Dekodiert ein 7-Bit-Hamming-Codewort und korrigiert Einzelbitfehler.
     * @param code Das empfangene 7-Bit-Codewort.
     * @return Die dekodierten 4 Datenbits.
     */
    static byte decode(byte code);

    /**
     * @brief Gibt den letzten Fehlerstatus zurück.
     * @return Fehlercode (0 = kein Fehler, 1 = korrigierbarer Fehler, 2 = nicht korrigierbarer Fehler).
     */
    static byte getLastError();

private:
    static byte lastError;  ///< Speichert den letzten Fehlerstatus.
};

#endif
