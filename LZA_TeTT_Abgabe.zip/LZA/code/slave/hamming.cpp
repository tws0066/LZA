/**
 * @file hamming.cpp
 * @author Tim Weynands, Tobias Radtke
 * @brief Implementierung der Hamming-Klasse für die Fehlerkorrektur und Codierung.
 * @date 06.03.2025
 */

#include "Hamming.hpp"

/**
 * @brief Der letzte Fehlerstatus bei der Decodierung.
 * 
 * Der Wert 0 bedeutet, dass kein Fehler gefunden wurde, alle anderen Werte
 * repräsentieren die Position des Fehlerbits.
 */
byte Hamming::lastError = 0;

/**
 * @brief Kodiert ein 4-Bit-Datenwort in einen 7-Bit-Hamming-Code.
 * 
 * Diese Funktion berechnet den Hamming-Code für ein 4-Bit-Datenwort. Der
 * Hamming-Code enthält zusätzlich Paritätsbits zur Fehlererkennung und -korrektur.
 * 
 * @param data Das 4-Bit-Datenwort, das codiert werden soll. Es muss kleiner als 16 (0x0F) sein.
 * @return byte Der berechnete 7-Bit-Hamming-Code.
 */
byte Hamming::code(byte data) {
    // Überprüfen, ob das Eingabedatenwort gültig ist
    if (data > 0x0F) return 0xFF;  ///< Rückgabe von 0xFF bei ungültigem Wert

    byte d1 = (data >> 3) & 1;  ///< Bit 3 des Datenworts (d1)
    byte d2 = (data >> 2) & 1;  ///< Bit 2 des Datenworts (d2)
    byte d3 = (data >> 1) & 1;  ///< Bit 1 des Datenworts (d3)
    byte d4 = data & 1;         ///< Bit 0 des Datenworts (d4)

    byte p1 = d1 ^ d2 ^ d4;  ///< Paritätsbit 1 (p1)
    byte p2 = d1 ^ d3 ^ d4;  ///< Paritätsbit 2 (p2)
    byte p3 = d2 ^ d3 ^ d4;  ///< Paritätsbit 3 (p3)

    // Zusammenfügen des 7-Bit-Hamming-Codes
    byte code = (p1 << 6) | (p2 << 5) | (d1 << 4) | (p3 << 3) | (d2 << 2) | (d3 << 1) | d4;
    return code;
}

/**
 * @brief Dekodiert einen 7-Bit-Hamming-Code und korrigiert Fehler, falls vorhanden.
 * 
 * Diese Funktion überprüft, ob der Hamming-Code einen Fehler enthält, und korrigiert diesen
 * falls notwendig. Sie gibt das dekodierte 4-Bit-Datenwort zurück.
 * 
 * @param code Der 7-Bit-Hamming-Code, der dekodiert werden soll.
 * @return byte Das dekodierte 4-Bit-Datenwort.
 */
byte Hamming::decode(byte code) {

    byte p1 = (code >> 6) & 1;  ///< Paritätsbit 1 (p1)
    byte p2 = (code >> 5) & 1;  ///< Paritätsbit 2 (p2)
    byte d1 = (code >> 4) & 1;  ///< Datenbit 1 (d1)
    byte p3 = (code >> 3) & 1;  ///< Paritätsbit 3 (p3)
    byte d2 = (code >> 2) & 1;  ///< Datenbit 2 (d2)
    byte d3 = (code >> 1) & 1;  ///< Datenbit 3 (d3)
    byte d4 = code & 1;         ///< Datenbit 4 (d4)

    // Berechnung der Syndrombits (Fehlerposition)
    byte s = (p1 ^ d1 ^ d2 ^ d4)
           | ((p2 ^ d1 ^ d3 ^ d4) << 1)
           | ((p3 ^ d2 ^ d3 ^ d4) << 2);

    Hamming::lastError = s; // 0 = kein Fehler, andere Werte repräsentieren die Fehlerposition

    // Falls ein Fehler aufgetreten ist, wird das fehlerhafte Bit korrigiert
    if (s)
        code ^= (1 << (7 - s));  ///< Fehlerbit korrigieren

    // Extrahieren des dekodierten 4-Bit-Datenworts
    byte decoded = (((code >> 4) & 1) << 3)
                 | (((code >> 2) & 1) << 2)
                 | (((code >> 1) & 1) << 1)
                 | (code & 1);
    return decoded;
}

/**
 * @brief Gibt den letzten Fehlerstatus zurück.
 * 
 * Diese Funktion gibt den Fehlerstatus der letzten Dekodierung zurück. 
 * 0 bedeutet, dass kein Fehler gefunden wurde. Ein Wert ungleich 0 gibt
 * die Position des fehlerhaften Bits an.
 * 
 * @return byte Der Fehlerstatus der letzten Dekodierung.
 */
byte Hamming::getLastError() {
    return Hamming::lastError;
}