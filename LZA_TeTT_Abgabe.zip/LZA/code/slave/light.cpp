/**
 * @file light.cpp
 * @author Tim Weynands, Tobias Radtke
 * @brief Implementierung der Light-Klasse zur Steuerung von LEDs.
 * @date 06.03.2025
 */

#include "light.hpp"

/**
 * @brief Konstruktor der Light-Klasse, initialisiert die LED.
 * 
 * Der Konstruktor initialisiert das Pin, an dem die LED angeschlossen ist,
 * und setzt den Initialwert auf LOW (LED aus).
 * 
 * @param pin Der Pin, an dem die LED angeschlossen ist. Standardwert ist 13.
 */
Light::Light(byte pin) {
  init(pin);
}

/**
 * @brief Initialisiert das Pin für die LED und setzt den Anfangszustand.
 * 
 * Diese Funktion wird im Konstruktor aufgerufen und setzt das angegebene Pin
 * als Ausgang. Die LED wird zu Beginn ausgeschaltet.
 * 
 * @param pin Der Pin, an dem die LED angeschlossen ist.
 */
void Light::init(int pin) {
  this->pin = pin; 
  pinMode(pin, OUTPUT);     ///< Setzt das Pin als Ausgang
  digitalWrite(pin, LOW);   ///< Setzt die LED auf "aus"
}

/**
 * @brief Schaltet die LED ein.
 * 
 * Diese Funktion setzt den Ausgang des angegebenen Pins auf HIGH und schaltet
 * damit die LED ein.
 */
void Light::switchOn() {
  digitalWrite(this->pin, HIGH);  ///< LED einschalten
}

/**
 * @brief Schaltet die LED aus.
 * 
 * Diese Funktion setzt den Ausgang des angegebenen Pins auf LOW und schaltet
 * damit die LED aus.
 */
void Light::switchOff() {
  digitalWrite(this->pin, LOW);   ///< LED ausschalten
}

/**
 * @brief Schaltet die LED um (ein/aus).
 * 
 * Diese Funktion prüft den aktuellen Zustand der LED. Falls die LED an ist,
 * wird sie ausgeschaltet, andernfalls wird sie eingeschaltet.
 */
void Light::toogle() {
  if (isOn()) {
    switchOff();   ///< Wenn die LED an ist, ausschalten
  } else {
    switchOn();    ///< Wenn die LED aus ist, einschalten
  }
}

/**
 * @brief Prüft, ob die LED eingeschaltet ist.
 * 
 * Diese Funktion liest den aktuellen Zustand des angegebenen Pins und gibt 
 * zurück, ob die LED an (HIGH) oder aus (LOW) ist.
 * 
 * @return bool Gibt true zurück, wenn die LED eingeschaltet ist, andernfalls false.
 */
bool Light::isOn() {
  return digitalRead(pin);  ///< Gibt den Zustand der LED zurück
}